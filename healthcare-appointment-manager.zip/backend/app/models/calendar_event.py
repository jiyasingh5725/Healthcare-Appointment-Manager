from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, Text, Boolean, ForeignKey, DateTime, func
from sqlalchemy.orm import relationship

from app.database import Base


class CalendarEvent(Base):
    """
    Google Calendar Event model tracking synchronization state for appointments.
    """
    __tablename__ = "calendar_events"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    appointment_id = Column(Integer, ForeignKey("appointments.id", ondelete="CASCADE"), unique=True, nullable=False, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    google_event_id = Column(String(255), nullable=True, index=True)
    calendar_id = Column(String(255), default="primary", nullable=False)
    status = Column(String(50), default="CONFIRMED", nullable=False, index=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)

    # Relationships
    appointment = relationship("Appointment", foreign_keys=[appointment_id], backref="calendar_event")
    user = relationship("User", foreign_keys=[user_id], backref="calendar_events")

    def __repr__(self) -> str:
        return f"<CalendarEvent(id={self.id}, appointment_id={self.appointment_id}, google_event_id='{self.google_event_id}', status='{self.status}')>"


class UserGoogleOAuth(Base):
    """
    Secure server-side storage for Google Calendar OAuth 2.0 credentials.
    Tokens are NEVER exposed in frontend API responses.
    """
    __tablename__ = "user_google_oauth"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), unique=True, nullable=False, index=True)
    access_token = Column(Text, nullable=False)
    refresh_token = Column(Text, nullable=True)
    token_expiry = Column(DateTime(timezone=True), nullable=True)
    scope = Column(String(500), default="https://www.googleapis.com/auth/calendar.events", nullable=False)
    is_connected = Column(Boolean, default=True, nullable=False)
    google_email = Column(String(255), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)

    # Relationship
    user = relationship("User", foreign_keys=[user_id], backref="google_oauth")

    def __repr__(self) -> str:
        return f"<UserGoogleOAuth(user_id={self.user_id}, is_connected={self.is_connected}, google_email='{self.google_email}')>"
